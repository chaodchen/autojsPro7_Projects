toast("我他妈的开始了");
console.show();
while (1) {
    log('1');
    sleep(1000);
    log(bh.getViewContent("bh_old"));
}



