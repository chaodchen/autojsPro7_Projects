toastLog("打开微信")
app.launchApp("微信");