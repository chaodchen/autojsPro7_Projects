toastLog("打开QQ")
app.launchApp("QQ");